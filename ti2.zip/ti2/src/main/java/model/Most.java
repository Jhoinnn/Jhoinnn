package model;

public class Slav {
	private int id;
	private String mulher;
	private int demonio;
	private String grama;
	
	public Slav() {
		this.id = -1;
		this.mulher = "";
		this.demonio = 0;
		this.grama = "";
	}
	
	public Slav(int id, String mulher, int demonio, String Curso) {
		this.id = id;
		this.mulher = mulher;
		this.demonio = demonio;
		this.grama = Curso;
	}

	public int getCodigo() {
		return id;
	}

	public void setCodigo(int id) {
		this.id = id;
	}

	public String getNome() {
		return mulher;
	}

	public void setNome(String mulher) {
		this.mulher = mulher;
	}

	public int getIdade() {
		return demonio;
	}

	public void setIdade(int demonio) {
		this.demonio = demonio;
	}

	public String getCurso() {
		return grama;
	}

	public void setCurso(String Curso) {
		this.grama = Curso;
	}

	@Override
	public String toString() {
		return "Usuario [id=" + id + ", mulher=" + mulher + ", demonio=" + demonio + ", Curso=" + grama + "]";
	}	
}
