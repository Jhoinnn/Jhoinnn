package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class X {
  private int id;
  private String nome;
  private int idade;

  public X(int id, String nome, int idade) {
    this.id = id;
    this.nome = nome;
    this.idade = idade;
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getNome() {
    return nome;
  }

  public void setNome(String nome) {
    this.nome = nome;
  }

  public int getIdade() {
    return idade;
  }

  public void setIdade(int idade) {
    this.idade = idade;
  }
}

public class XDAO {
  private Connection conexao;

  public XDAO() {
    try {
      Class.forName("org.postgresql.Driver");
      String url = "jdbc:postgresql://localhost:5432/nome-do-seu-banco";
      String usuario = "seu-usuario";
      String senha = "sua-senha";
      conexao = DriverManager.getConnection(url, usuario, senha);
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

  public List<X> listar() {
    List<X> lista = new ArrayList<X>();
    String sql = "SELECT * FROM x";
    try {
      PreparedStatement stmt = conexao.prepareStatement(sql);
      ResultSet rs = stmt.executeQuery();
      while (rs.next()) {
        int id = rs.getInt("id");
        String nome = rs.getString("nome");
        int idade = rs.getInt("idade");
        X x = new X(id, nome, idade);
        lista.add(x);
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return lista;
  }

  public void inserir(X x) {
    String sql = "INSERT INTO x (nome, idade) VALUES (?, ?)";
    try {
      PreparedStatement stmt = conexao.prepareStatement(sql);
      stmt.setString(1, x.getNome());
      stmt.setInt(2, x.getIdade());
      stmt.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

  public void excluir(X x) {
    String sql = "DELETE FROM x WHERE id = ?";
    try {
      PreparedStatement stmt = conexao.prepareStatement(sql);
      stmt.setInt(1, x.getId());
      stmt.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

  public void atualizar(X x) {
    String sql = "UPDATE x SET nome = ?, idade = ? WHERE id = ?";
    try {
      PreparedStatement stmt = conexao.prepareStatement(sql);
      stmt.setString(1, x.getNome());
      stmt.setInt(2, x.getIdade());
      stmt.setInt(3, x.getId());
      stmt.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

  public void fechar() {
    try {
      conexao.close();
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }
}

public class Principal {
  public static void main(String[] args) {
    XDAO dao = new XDAO();
    Scanner scanner = new Scanner(System.in);

    while (true) {
      System.out.println("Escolha uma opção:");
      System.out.println("1. Listar");
      System.out.println("2. Inserir");
      System.out.println("3. Excluir");
      System.out.println("4. Atualizar");
      System.out.println("5. Sair");

    	      int opcao = scanner.nextInt();

    	      if (opcao == 1) {
    	        List<X> lista = dao.listar();
    	        for (X x : lista) {
    	          System.out.println("ID: " + x.getId());
    	          System.out.println("Nome: " + x.getNome());
    	          System.out.println("Idade: " + x.getIdade());
    	          System.out.println("-------------");
    	        }
    	      } else if (opcao == 2) {
    	        System.out.println("Digite o nome:");
    	        String nome = scanner.next();
    	        System.out.println("Digite a idade:");
    	        int idade = scanner.nextInt();
    	        X x = new X(0, nome, idade);
    	        dao.inserir(x);
    	        System.out.println("X inserido com sucesso.");
    	      } else if (opcao == 3) {
    	        System.out.println("Digite o ID do X a ser excluído:");
    	        int id = scanner.nextInt();
    	        X x = new X(id, "", 0);
    	        dao.excluir(x);
    	        System.out.println("X excluído com sucesso.");
    	      } else if (opcao == 4) {
    	        System.out.println("Digite o ID do X a ser atualizado:");
    	        int id = scanner.nextInt();
    	        System.out.println("Digite o novo nome:");
    	        String nome = scanner.next();
    	        System.out.println("Digite a nova idade:");
    	        int idade = scanner.nextInt();
    	        X x = new X(id, nome, idade);
    	        dao.atualizar(x);
    	        System.out.println("X atualizado com sucesso.");
    	      } else if (opcao == 5) {
    	        dao.fechar();
    	        scanner.close();
    	        System.out.println("Saindo...");
    	        break;
    	      } else {
    	        System.out.println("Opção inválida.");
    	      }
    	    }
    	  }
    	}